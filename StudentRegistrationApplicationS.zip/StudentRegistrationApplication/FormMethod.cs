﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentRegistrationApplication
{
    
    internal class FormMethod
    {


        public void FormsInsert(string Lastname, string Firstname, string Program)
        {

            MessageBox.Show("Student name: " + Firstname + " " + Lastname + "\n" +
                            "Program: " + Program, "Method Overload 1");
        }

        public void FormsInsert(string Lastname, string Firstname, string Middlename, string Program)
        {

            MessageBox.Show("Student name: " + Firstname + " " + Middlename + " " + Lastname + "\n" +
                           "Program: " + Program, "Method Overload 2");
        }

        public void FormsInsert(string Lastname, string Firstname, string Middlename, string gender, string Dob, string Program)
        {

            MessageBox.Show("Student name: " + Firstname + " " + Middlename + " " + Lastname + "\n" +
                            "Gender: " + gender + "\n" +
                            "Date of Birth: " + Dob + "\n" +
                            "Program: " + Program, "Method Overload 3");
        }



    }
}
