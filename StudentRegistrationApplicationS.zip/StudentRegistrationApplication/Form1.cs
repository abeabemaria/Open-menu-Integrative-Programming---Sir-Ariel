﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentRegistrationApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog diag = new OpenFileDialog();
            diag.Filter = "Image Files|*.jpg; *.png; *.jpeg";

            if(diag.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(diag.FileName);


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormMethod obj1 = new FormMethod();


            string datebirth = "";
            string gender = "";

            if(dob1.Text != "-Day-" && dob2.Text != "-Month-" && dob3.Text != "-Year-")
            {
                datebirth = dob3.Text + "-" + dob2.Text + "-" + dob1.Text;
            }


            if (r1.Checked)
            {
                gender = "Male";
                r2.Checked = false;
            }
            if (r2.Checked)
            {
                gender = "Female";
                r1.Checked = false;
            }

            if (!string.IsNullOrEmpty(lnametxt.Text) &&
                     !string.IsNullOrEmpty(fnametxt.Text) &&
                     !string.IsNullOrEmpty(gender) &&
                     !string.IsNullOrEmpty(datebirth) &&
                     !string.IsNullOrEmpty(midnametxt.Text) &&
                    (programtxt.Text != "-Select Program-"))
            {
                obj1.FormsInsert(lnametxt.Text, fnametxt.Text, midnametxt.Text, gender, datebirth, programtxt.Text);
                
            }
            else if (!string.IsNullOrEmpty(lnametxt.Text) &&
                     !string.IsNullOrEmpty(fnametxt.Text) &&
                     !string.IsNullOrEmpty(midnametxt.Text) &&
                    (programtxt.Text != "-Select Program-"))
            {
                obj1.FormsInsert(lnametxt.Text, fnametxt.Text, midnametxt.Text, programtxt.Text);
                
            }
            else if (!string.IsNullOrEmpty(lnametxt.Text) &&
                !string.IsNullOrEmpty(fnametxt.Text) &&
                (programtxt.Text != "-Select Program-")) {

                obj1.FormsInsert(lnametxt.Text, fnametxt.Text, programtxt.Text);
                

            }
            else
            {
                MessageBox.Show("Invalid Input!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ArrayList programtypes = new ArrayList();
            programtypes.Add("Bachelor of Science Information Technology");
            programtypes.Add("Bachelor of Science Tourism Management");
            programtypes.Add("Bachelor of Science Hospitality Management");


            ArrayList Month = new ArrayList();
            Month.Add("January");
            Month.Add("February");
            Month.Add("March");
            Month.Add("April");
            Month.Add("May");
            Month.Add("June");
            Month.Add("July");
            Month.Add("August");
            Month.Add("September");
            Month.Add("October");
            Month.Add("November");
            Month.Add("December");


            foreach (string i in programtypes)
            {
                programtxt.Items.Add(i);
            }

            for(int i = 1; i <= 30; i++)
            {
                dob1.Items.Add(i);
            }
            foreach (string i in Month)
            {
                dob2.Items.Add(i);
            }
            for (int i = 1999; i <= 2026; i++)
            {
                dob3.Items.Add(i);
            }
        }
    }
}
