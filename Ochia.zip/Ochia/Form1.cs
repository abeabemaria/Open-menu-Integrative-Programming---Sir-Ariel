﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ochia
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ArrayList name_category = new ArrayList();

            name_category.Add("Dish");
            name_category.Add("Juice");
            name_category.Add("Snacks");

            foreach (string category in name_category)
           {
                tabcategory.Items.Add(category);
        
            }

        }

        private void tabcategory_SelectedIndexChanged(object sender, EventArgs e)
        {

            ArrayList Dish = new ArrayList();
            ArrayList Juice = new ArrayList();
            ArrayList Snacks = new ArrayList();

            Dish.Add("Fish");
            Dish.Add("Chicken");
            Dish.Add("Pork");

            Juice.Add("Orange");
            Juice.Add("Apple");
            Juice.Add("Grapes");

            Snacks.Add("Patata");
            Snacks.Add("Oishi");
            Snacks.Add("Martys");

            if(tabcategory.Text == "Dish")
            {
                tabprice.Text = "";
                tabitems.Text = "";
                tabitems.Items.Clear();
                foreach (String dish in Dish)
                {
                   
                    tabitems.Items.Add(dish);
           
            }       

            }
            if (tabcategory.Text == "Juice")
            {
                tabprice.Text = "";
                tabitems.Text = "";
                tabitems.Items.Clear();
                foreach (String juice in Juice)
                {
                    
                    tabitems.Items.Add(juice);
                }


            }  if (tabcategory.Text == "Snacks")
            {
                tabprice.Text = "";
                tabitems.Text = "";
                tabitems.Items.Clear();
                foreach (String snacks in Snacks)
                {
                    tabitems.Items.Add(snacks);

                }
            }

                


            }

        private void tabitems_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (tabcategory.SelectedItem == "Dish")
            {

                if(tabitems.SelectedIndex == 0)
                {
                    tabprice.Text = "140";

                }
                else if (tabitems.SelectedIndex == 1){

                    tabprice.Text = "150";

                }
                else if (tabitems.SelectedIndex == 2)
                {

                    tabprice.Text = "200";
                }
                

            }

           else if(tabcategory.SelectedItem == "Juice")
            {
                if(tabitems.SelectedIndex == 0) {

                    tabprice.Text = "60";
                
                
            }
                else if (tabitems.SelectedIndex == 1){

                    tabprice.Text = "70";


                }

                else if (tabitems.SelectedIndex== 2)
                {
                    tabprice.Text = "80";


                }

            }

            else if (tabcategory.SelectedItem == "Snacks")
            {
                if (tabitems.SelectedIndex == 0)
                {

                    tabprice.Text = "10";


                }
                else if (tabitems.SelectedIndex == 1)
                {

                    tabprice.Text = "20";


                }

                else if (tabitems.SelectedIndex == 2)
                {
                    tabprice.Text = "30";


                }

                


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {


            MessageBox.Show("Buyers name: " + tabname.Text + 
                "\nCategory: " + tabcategory.Text + "\nItems: " + tabitems.Text + "\nPrice: " + tabprice.Text);
            
        }
    }

}
