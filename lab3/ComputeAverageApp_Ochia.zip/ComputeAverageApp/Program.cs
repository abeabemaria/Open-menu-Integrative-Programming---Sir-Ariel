﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputeAverageApp
{
    internal class ComputeAverageProgram
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter 5 grades separated by new line: ");
            double college1 = Convert.ToDouble(Console.ReadLine());
            double college2 = Convert.ToDouble(Console.ReadLine());
            double college3 = Convert.ToDouble(Console.ReadLine());
            double college4 = Convert.ToDouble(Console.ReadLine());
            double college5 = Convert.ToDouble(Console.ReadLine());

            double sum = (college1 + college2 + college3 + college4 + college5) / 5;

            Console.WriteLine("The average is " + sum + " and round off to " + Math.Round(sum) + " goodjob!" );

            Console.Write("Press any key to exit");
            Console.ReadKey();







        }
    }
}
